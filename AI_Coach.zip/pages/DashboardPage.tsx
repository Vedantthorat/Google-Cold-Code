
import React from 'react';
import Card from '../components/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Jan', skills: 4, tests: 2 },
  { name: 'Feb', skills: 3, tests: 5 },
  { name: 'Mar', skills: 6, tests: 4 },
  { name: 'Apr', skills: 7, tests: 6 },
  { name: 'May', skills: 8, tests: 7 },
  { name: 'Jun', skills: 10, tests: 8 },
];

const StatCard: React.FC<{ icon: string; label: string; value: string; color: string }> = ({ icon, label, value, color }) => (
    <Card className="flex items-center p-5">
        <div className={`p-3 rounded-full mr-4 ${color}`}>
            <i data-lucide={icon} className="h-6 w-6 text-white"></i>
        </div>
        <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">{label}</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
        </div>
    </Card>
);

const DashboardPage: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard icon="briefcase" label="Job Readiness" value="82%" color="bg-blue-500" />
          <StatCard icon="star" label="Skills Mastery" value="75%" color="bg-green-500" />
          <StatCard icon="file-check" label="Tests Taken" value="12" color="bg-yellow-500" />
          <StatCard icon="trending-up" label="Learning Progress" value="68%" color="bg-indigo-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
            <Card title="Your Progress Over Time" icon="activity">
                <div style={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer>
                    <BarChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-gray-200 dark:stroke-gray-700" />
                        <XAxis dataKey="name" className="text-xs" />
                        <YAxis className="text-xs" />
                        <Tooltip
                            contentStyle={{
                                backgroundColor: 'rgba(255, 255, 255, 0.8)',
                                backdropFilter: 'blur(5px)',
                                border: '1px solid #ccc',
                                borderRadius: '0.5rem',
                                color: '#333'
                            }}
                        />
                        <Legend />
                        <Bar dataKey="skills" fill="#3b82f6" name="Skills Acquired" />
                        <Bar dataKey="tests" fill="#84cc16" name="Tests Passed" />
                    </BarChart>
                    </ResponsiveContainer>
                </div>
            </Card>
        </div>
        <div>
            <Card title="Quick Actions" icon="zap">
                <div className="space-y-3">
                    <button className="w-full flex items-center text-left p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                        <i data-lucide="file-pen" className="h-5 w-5 mr-3 text-primary-500"></i>
                        <span>Take a Test</span>
                    </button>
                    <button className="w-full flex items-center text-left p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                        <i data-lucide="upload" className="h-5 w-5 mr-3 text-primary-500"></i>
                        <span>Update Resume</span>
                    </button>
                    <button className="w-full flex items-center text-left p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                        <i data-lucide="eye" className="h-5 w-5 mr-3 text-primary-500"></i>
                        <span>View Recommendations</span>
                    </button>
                     <button className="w-full flex items-center text-left p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                        <i data-lucide="message-circle" className="h-5 w-5 mr-3 text-primary-500"></i>
                        <span>Chat with Coach</span>
                    </button>
                </div>
            </Card>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
