
import React, { useState } from 'react';
import Card from '../components/Card';
import { Recommendation } from '../types';

const mockRecommendations: Recommendation[] = [
  { id: 'j1', type: 'Job', title: 'Frontend Developer at TechCorp', source: 'LinkedIn', summary: 'Exciting role for a React developer to build next-gen UIs.', reason: 'Matches 5/6 required skills; Strong in React.', relevance: 95 },
  { id: 'c1', type: 'Course', title: 'Advanced TypeScript', source: 'Udemy', summary: 'Deep dive into advanced TypeScript features for large-scale applications.', reason: 'Skill gap identified: Advanced TypeScript.', relevance: 92 },
  { id: 'j2', type: 'Job', title: 'Full Stack Engineer at Innovate LLC', source: 'Indeed', summary: 'Work with Node.js and React on a fast-growing platform.', reason: 'Matches 4/6 required skills; Missing: AWS.', relevance: 88 },
  { id: 'p1', type: 'Project', title: 'Build a Personal Portfolio Website', source: 'Internal', summary: 'Showcase your skills by building a dynamic portfolio with React.', reason: 'Good for demonstrating practical skills.', relevance: 85 },
];

const RecommendationCard: React.FC<{ item: Recommendation }> = ({ item }) => (
    <Card className="mb-4 transition-transform transform hover:scale-105">
        <div className="flex justify-between items-start">
            <div>
                <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                    item.type === 'Job' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300' :
                    item.type === 'Course' ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' :
                    'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300'
                }`}>{item.type}</span>
                <h4 className="text-lg font-bold mt-2 text-gray-900 dark:text-white">{item.title}</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">{item.source}</p>
            </div>
            <div className="text-right">
                <p className="font-bold text-lg text-primary-500">{item.relevance}%</p>
                <p className="text-xs text-gray-500">Match</p>
            </div>
        </div>
        <p className="text-sm text-gray-600 dark:text-gray-300 mt-3">{item.summary}</p>
        <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <p className="text-xs font-semibold text-gray-700 dark:text-gray-300">Why it's recommended:</p>
            <p className="text-sm text-gray-600 dark:text-gray-400">{item.reason}</p>
        </div>
        <div className="mt-4 flex space-x-2">
            <button className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-lg hover:bg-primary-700">Apply / View</button>
            <button className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600">Save</button>
        </div>
    </Card>
);

const RecommendationsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('All');
  const tabs = ['All', 'Jobs', 'Courses', 'Projects'];

  const filteredRecs = activeTab === 'All'
    ? mockRecommendations
    : mockRecommendations.filter(r => r.type === activeTab.slice(0, -1));

  return (
    <div>
      <div className="mb-6">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="-mb-px flex space-x-8" aria-label="Tabs">
            {tabs.map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`${
                  activeTab === tab
                    ? 'border-primary-500 text-primary-600 dark:text-primary-400'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
              >
                {tab}
              </button>
            ))}
          </nav>
        </div>
      </div>
      <div>
        {filteredRecs.map(rec => <RecommendationCard key={rec.id} item={rec} />)}
      </div>
    </div>
  );
};

export default RecommendationsPage;
