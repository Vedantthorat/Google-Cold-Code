
import React, { useState, useRef, useEffect } from 'react';
import { getChatInstance } from '../services/geminiService.ts';
import { GenerateContentResponse } from '@google/genai';

interface Message {
  sender: 'user' | 'bot';
  text: string;
}

const ChatbotPage: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { sender: 'bot', text: "Hello! I'm your AI Career Coach. How can I help you today?" },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);
  
  // Refresh icons on state change
  useEffect(() => {
    if (window.lucide) {
      window.lucide.createIcons();
    }
  });

  const handleSend = async () => {
    if (input.trim() === '') return;

    const userMessage: Message = { sender: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
        const chat = getChatInstance();
        const result = await chat.sendMessageStream({ message: input });

        let botResponse = '';
        setMessages(prev => [...prev, { sender: 'bot', text: '' }]);
        
        for await (const chunk of result) {
            botResponse += chunk.text;
            setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = { sender: 'bot', text: botResponse };
                return newMessages;
            });
        }

    } catch (error) {
      console.error('Gemini chat error:', error);
      setMessages(prev => [...prev, { sender: 'bot', text: "Sorry, I'm having trouble connecting right now." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-10rem)] bg-white dark:bg-gray-950 rounded-xl shadow-lg">
      <div className="flex-1 p-6 overflow-y-auto">
        <div className="space-y-4">
          {messages.map((msg, index) => (
            <div key={index} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
              {msg.sender === 'bot' && <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary-500 flex items-center justify-center"><i data-lucide="bot" className="w-5 h-5 text-white"></i></div>}
              <div className={`px-4 py-3 rounded-2xl max-w-lg ${msg.sender === 'user' ? 'bg-primary-500 text-white rounded-br-none' : 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-bl-none'}`}>
                <p className="text-sm" dangerouslySetInnerHTML={{ __html: msg.text.replace(/\n/g, '<br />') }}></p>
              </div>
            </div>
          ))}
          {isLoading && (
             <div className="flex items-start gap-3">
               <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary-500 flex items-center justify-center"><i data-lucide="bot" className="w-5 h-5 text-white"></i></div>
                <div className="px-4 py-3 rounded-2xl bg-gray-100 dark:bg-gray-800 rounded-bl-none flex items-center">
                    <div className="w-2 h-2 bg-primary-500 rounded-full animate-bounce" style={{animationDelay: '0s'}}></div>
                    <div className="w-2 h-2 bg-primary-500 rounded-full animate-bounce ml-1" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-2 h-2 bg-primary-500 rounded-full animate-bounce ml-1" style={{animationDelay: '0.2s'}}></div>
                </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
      <div className="p-4 border-t border-gray-200 dark:border-gray-800">
        <div className="flex items-center bg-gray-100 dark:bg-gray-800 rounded-lg">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSend()}
            placeholder="Ask me anything about your career..."
            className="flex-1 w-full px-4 py-3 bg-transparent border-none rounded-lg focus:ring-0"
            disabled={isLoading}
          />
          <button onClick={handleSend} disabled={isLoading} className="p-3 text-primary-500 disabled:text-gray-400">
            <i data-lucide="send" className="w-5 h-5"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatbotPage;
