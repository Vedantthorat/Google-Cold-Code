
import React, { useState, useCallback } from 'react';
import Card from '../components/Card';
import { parseResumeWithGemini } from '../services/geminiService';
import { ParsedResume } from '../types';
import { fileToBase64 } from '../utils/helpers';

const ProfilePage: React.FC = () => {
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<ParsedResume | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      setResumeFile(event.target.files[0]);
    }
  };

  const handleParseResume = useCallback(async () => {
    if (!resumeFile) {
      setError('Please select a resume file first.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setParsedData(null);
    try {
      const data = await parseResumeWithGemini(resumeFile);
      setParsedData(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [resumeFile]);
  
  const renderParsedData = () => {
    if (!parsedData) return null;
    return (
      <div className="space-y-6 mt-6 animate-fade-in">
        <Card title="Personal Information">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div><strong className="text-gray-500">Name:</strong> {parsedData.personalInfo.name}</div>
            <div><strong className="text-gray-500">Email:</strong> {parsedData.personalInfo.email}</div>
            <div><strong className="text-gray-500">Phone:</strong> {parsedData.personalInfo.phone}</div>
          </div>
        </Card>
        <Card title="Skills">
            <div className="flex flex-wrap gap-2">
                {parsedData.skills.map((skill, index) => (
                    <span key={index} className="px-3 py-1 text-sm bg-primary-100 text-primary-800 rounded-full dark:bg-primary-900/50 dark:text-primary-300">{skill}</span>
                ))}
            </div>
        </Card>
        <Card title="Work Experience">
            <div className="space-y-4">
            {parsedData.experience.map((exp, index) => (
                <div key={index} className="border-b dark:border-gray-700 pb-2 last:border-b-0">
                    <h4 className="font-semibold">{exp.title} at {exp.company}</h4>
                    <p className="text-sm text-gray-500">{exp.duration}</p>
                    <ul className="list-disc list-inside mt-2 text-sm text-gray-600 dark:text-gray-400">
                        {exp.responsibilities.map((resp, i) => <li key={i}>{resp}</li>)}
                    </ul>
                </div>
            ))}
            </div>
        </Card>
         <Card title="Education">
            {parsedData.education.map((edu, index) => (
                <div key={index}>
                    <h4 className="font-semibold">{edu.degree}</h4>
                    <p className="text-sm text-gray-500">{edu.institution} ({edu.year})</p>
                </div>
            ))}
        </Card>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      <Card title="Upload Your Resume" icon="upload">
        <p className="mb-4 text-gray-600 dark:text-gray-400">
          Upload your resume (PDF, DOCX) to automatically parse and fill in your profile.
        </p>
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <input
            type="file"
            accept=".pdf,.docx"
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary-50 file:text-primary-700 hover:file:bg-primary-100 dark:file:bg-primary-900/50 dark:file:text-primary-300 dark:hover:file:bg-primary-900"
          />
          <button
            onClick={handleParseResume}
            disabled={isLoading || !resumeFile}
            className="w-full sm:w-auto px-6 py-2.5 text-sm font-medium text-white bg-primary-600 rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isLoading ? (
                <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Parsing...
                </>
            ) : "Parse with AI"}
          </button>
        </div>
        {error && <p className="mt-4 text-sm text-red-500">{error}</p>}
      </Card>
      {renderParsedData()}
    </div>
  );
};

export default ProfilePage;
