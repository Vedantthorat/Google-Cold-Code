
import React from 'react';
import Card from '../components/Card';
import { useTheme } from '../hooks/useTheme';
import { Theme } from '../types';

const Toggle: React.FC<{ label: string; enabled: boolean; onChange: () => void }> = ({ label, enabled, onChange }) => (
  <div className="flex items-center justify-between py-4">
    <span className="text-gray-700 dark:text-gray-300">{label}</span>
    <button
      onClick={onChange}
      className={`${
        enabled ? 'bg-primary-600' : 'bg-gray-300 dark:bg-gray-700'
      } relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-gray-900`}
    >
      <span
        className={`${
          enabled ? 'translate-x-6' : 'translate-x-1'
        } inline-block w-4 h-4 transform bg-white rounded-full transition-transform`}
      />
    </button>
  </div>
);

const SettingsPage: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Settings</h1>
      <div className="space-y-8">
        <Card title="Appearance" icon="eye">
          <Toggle
            label="Dark Mode"
            enabled={theme === Theme.Dark}
            onChange={toggleTheme}
          />
        </Card>
        <Card title="Privacy" icon="lock">
            <Toggle label="Share resume with recruiters" enabled={true} onChange={() => {}} />
            <div className="border-t border-gray-200 dark:border-gray-700 my-2"></div>
            <Toggle label="Share test scores" enabled={false} onChange={() => {}} />
        </Card>
        <Card title="Account" icon="user">
            <button className="w-full text-left text-red-600 dark:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 p-4 rounded-lg transition-colors">
                Delete Account
            </button>
        </Card>
      </div>
    </div>
  );
};

export default SettingsPage;
