
import React, { ReactNode } from 'react';

interface CardProps {
  title?: string;
  children: ReactNode;
  className?: string;
  icon?: string;
}

const Card: React.FC<CardProps> = ({ title, children, className, icon }) => {
  return (
    <div className={`bg-white dark:bg-gray-950 rounded-xl shadow-md overflow-hidden ${className}`}>
      {title && (
        <div className="p-5 border-b border-gray-200 dark:border-gray-800 flex items-center">
          {icon && <i data-lucide={icon} className="h-5 w-5 mr-3 text-primary-500"></i>}
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{title}</h3>
        </div>
      )}
      <div className="p-5">
        {children}
      </div>
    </div>
  );
};

export default Card;
