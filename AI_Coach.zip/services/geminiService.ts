
import { GoogleGenAI, Chat, GenerateContentResponse, Type } from "@google/genai";
import { ParsedResume } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. Please set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const parseResumeWithGemini = async (file: File): Promise<ParsedResume> => {
  const model = 'gemini-2.5-flash';

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = error => reject(error);
    });
  };

  const base64Data = await fileToBase64(file);

  const filePart = {
    inlineData: {
      mimeType: file.type,
      data: base64Data,
    },
  };

  const resumeSchema = {
    type: Type.OBJECT,
    properties: {
      personalInfo: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          email: { type: Type.STRING },
          phone: { type: Type.STRING },
        },
      },
      summary: { type: Type.STRING },
      skills: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
      },
      experience: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            company: { type: Type.STRING },
            duration: { type: Type.STRING },
            responsibilities: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
        },
      },
      education: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            degree: { type: Type.STRING },
            institution: { type: Type.STRING },
            year: { type: Type.STRING },
          },
        },
      },
    },
  };

  const response = await ai.models.generateContent({
    model: model,
    contents: { parts: [filePart, { text: "Extract the resume information from this file into a structured JSON format." }] },
    config: {
      responseMimeType: 'application/json',
      responseSchema: resumeSchema
    }
  });

  const jsonString = response.text.trim();
  try {
    const parsedJson = JSON.parse(jsonString);
    return parsedJson as ParsedResume;
  } catch (e) {
    console.error("Failed to parse Gemini response as JSON", e);
    throw new Error("Could not parse the resume. The format might be unsupported.");
  }
};

let chatInstance: Chat | null = null;

export const getChatInstance = (): Chat => {
    if (!chatInstance) {
        chatInstance = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: `You are an AI Career Coach for college students. Your goal is to provide helpful, encouraging, and actionable advice. 
                Keep your responses concise and easy to understand. Use markdown for formatting when appropriate.
                If asked for recommendations, frame them as suggestions.
                Do not provide financial advice.
                You can help with resume tips, interview practice, learning path suggestions, and general career questions.`
            }
        });
    }
    return chatInstance;
}
