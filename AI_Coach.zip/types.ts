
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'Student' | 'Recruiter' | 'Admin';
  fitScore?: number;
  jobReadiness?: number;
  skillsMastery?: number;
}

export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
}

export enum Theme {
  Light = 'light',
  Dark = 'dark'
}

export interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

export interface ParsedResume {
  personalInfo: {
    name: string;
    email: string;
    phone: string;
  };
  summary: string;
  skills: string[];
  experience: {
    title: string;
    company: string;
    duration: string;
    responsibilities: string[];
  }[];
  education: {
    degree: string;
    institution: string;
    year: string;
  }[];
}

export interface Recommendation {
  id: string;
  type: 'Job' | 'Course' | 'Project' | 'Mentor' | 'Internship';
  title: string;
  source: string;
  summary: string;
  reason: string;
  relevance: number;
}
